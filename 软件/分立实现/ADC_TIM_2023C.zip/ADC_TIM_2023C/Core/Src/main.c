/* USER CODE BEGIN Header */
/**
 ******************************************************************************
 * @file           : main.c
 * @brief          : Main program body
 ******************************************************************************
 * @attention
 *
 * Copyright (c) 2023 STMicroelectronics.
 * All rights reserved.
 *
 * This software is licensed under terms that can be found in the LICENSE file
 * in the root directory of this software component.
 * If no LICENSE file comes with this software, it is provided AS-IS.
 *
 ******************************************************************************
 */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "adc.h"
#include "dac.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdio.h>
#include <math.h>
// #include "math.h"
// #include "arm_math.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
//32的adc的相位和增益采集次数
#define phaseadctimes 60
#define gainadctimes 60


//相位和增益取平均次数
#define phaseaveragetimes 3	
#define gainaveragetimes 3	

//stm32的adc和实际真实的值直接的倍数关系为adc*0.9668=真实值
#define adc_compensate 0.9668

//AD8302 20K幅度1V的相位输出电压和相位差之间的一次函数关系
#define AD8302_phase_intercept 1.9206
#define AD8302_phase_slope 0.0112

//计算得出的波形相位关系和实际波形相位关系之间的一次函数关系
#define phase_compensate_intercept 1.257
#define phase_compensate_slope 0.9703

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

//相位和增益的adc采集次数
int phaseadctime = 0;
int gainadctime = 0;
float sum = 0;
float sum1 = 0;

//相位和增益的adctimes次采集完成标志位
int phase_flag = 0;
int gain_flag = 0;

//32adc采集的真实值
float realadc = 0;
float realadc1 = 0;

//计算的相位分别存在三个数组里，三次采集相位算平均
float phase[phaseaveragetimes];
float dB[gainaveragetimes];

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

//AD8302 20K同相的输出电压和增益比之间的二次函数关系为y = 0.0287x2 - 0.2568x + 1.1612，其中y为输出电压，x为增益倍数
float solve_equation_dB(float vol);

//计算相位大小
float phase_calculate(float realadc);

//计算增益大小
float gain_calculate(float realadc);

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART1_UART_Init();
  MX_DAC_Init();
  MX_ADC2_Init();
  MX_ADC1_Init();
  MX_TIM2_Init();
  MX_TIM3_Init();
  /* USER CODE BEGIN 2 */

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  HAL_ADC_Start_IT(&hadc2);
  HAL_TIM_Base_Start(&htim3);

    while (1)
    {

    }


    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */

  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 4;
  RCC_OscInitStruct.PLL.PLLN = 168;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */
__weak void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef *hadc)
{
	if((hadc->Instance == ADC2)&(phaseadctime == phaseadctimes))
	{
    //stm32的adc是不准的，这里取平均值并结合实验误差，得出真实值 
    realadc = adc_compensate*(sum/phaseadctimes);
    realadc1 = adc_compensate*(sum1/phaseadctimes);

    printf("realadc:%f\r\n",realadc);
    printf("realadc1:%f\r\n",realadc1);

    //计算相位
    phase_calculate(realadc);
    gain_calculate(realadc1);

    // //计算增益
    // gain_calculate(realadc);

	  phaseadctime = 0;
	  sum = 0;
    sum1 = 0;


	}

	else
	{
    //adc测量phaseadctimes次后取平均值
		int vol = HAL_ADC_GetValue(&hadc2);
    int vol1 = HAL_ADC_GetValue(&hadc1);
		float volt = (3.3 * vol /4096);
		float volt1 = (3.3 * vol1 /4096);

		sum = sum +volt;
    sum1 = sum1 +volt1;
		phaseadctime++;
	}

  
}

float solve_equation_dB(float vol)
{
  return (-0.0227+sqrt((0.0227)*(0.0227)-4*(0.0008)*(0.9383-vol)))/(2*0.0008);
  //return (vol-0.936)/0.0294;
}


float phase_calculate(float realadc)
{

    //用公式计算相位差
		phase[phase_flag] = (AD8302_phase_intercept-realadc)/AD8302_phase_slope;
		phase_flag++;

		if(phase_flag == phaseaveragetimes)
		{
      
			printf("%f\r\n",realadc);

      //拟合时计算相位平均相位差，提高精度
			float phase_average = (phase[0]+phase[1]+phase[2])/phaseaveragetimes;  

      //计算补偿拟合后的实际相位
			float real_phase = (phase_average-phase_compensate_intercept)/phase_compensate_slope; 
			printf("%f\r\n",real_phase);
			
      //清除标志位
      phase_flag = 0; 

      //停止定时器，只算一次
			HAL_TIM_Base_Stop(&htim3);

      return real_phase;
     }
}



float gain_calculate(float realadc)
{
  dB[gain_flag] = solve_equation_dB(realadc);
  gain_flag++;

  if(gain_flag == gainaveragetimes)
   {
    //计算dB平均值
    float realdB = (dB[0]+dB[1]+dB[2])/gainaveragetimes;
    // printf("realdB:%f",realdB);

    //通过dB算增益
    float realgain = pow(10,realdB/20);
    printf("averagegain:%f\r\n",realgain);

    //清除标志位
    gain_flag = 0;

    //停止定时器，只算一次
		//HAL_TIM_Base_Stop(&htim3);

    return realgain;
   }

}


/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
    /* User can add his own implementation to report the HAL error return state */
    __disable_irq();
    while (1) {
    }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
    /* User can add his own implementation to report the file name and line number,
       ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
